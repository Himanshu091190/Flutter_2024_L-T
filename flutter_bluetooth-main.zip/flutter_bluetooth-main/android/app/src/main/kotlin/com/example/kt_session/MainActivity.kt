package com.example.kt_session

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
