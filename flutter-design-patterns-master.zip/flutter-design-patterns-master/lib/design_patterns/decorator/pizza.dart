abstract interface class Pizza {
  String getDescription();
  double getPrice();
}
