import 'package:flutter/widgets.dart';

abstract interface class IActivityIndicator {
  Widget render();
}
