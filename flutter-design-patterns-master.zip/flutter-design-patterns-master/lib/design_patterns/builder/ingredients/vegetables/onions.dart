import '../../ingredient.dart';

class Onions extends Ingredient {
  Onions() {
    name = 'Onions';
    allergens = [];
  }
}
