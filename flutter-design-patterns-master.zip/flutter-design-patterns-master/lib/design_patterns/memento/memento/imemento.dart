import '../command_design_pattern/shape.dart';

abstract interface class IMemento {
  Shape getState();
}
