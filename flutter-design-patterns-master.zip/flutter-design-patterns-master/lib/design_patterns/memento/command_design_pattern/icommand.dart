abstract interface class ICommand {
  void execute();
  void undo();
}
