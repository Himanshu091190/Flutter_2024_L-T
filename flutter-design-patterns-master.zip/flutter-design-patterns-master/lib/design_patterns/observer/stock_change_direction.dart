enum StockChangeDirection {
  falling,
  growing,
}
