import 'contact.dart';

abstract interface class IContactsAdapter {
  List<Contact> getContacts();
}
