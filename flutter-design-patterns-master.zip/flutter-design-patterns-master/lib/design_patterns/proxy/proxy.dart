export 'customer/customer.dart';
export 'customer/customer_details.dart';
export 'customer_details_service.dart';
export 'customer_details_service_proxy.dart';
export 'icustomer_details_service.dart';
