abstract interface class ITreeIterator {
  bool hasNext();
  int? getNext();
  void reset();
}
