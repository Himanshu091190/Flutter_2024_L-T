class TvApi {
  const TvApi();

  bool turnOn() => true;

  bool turnOff() => false;
}
