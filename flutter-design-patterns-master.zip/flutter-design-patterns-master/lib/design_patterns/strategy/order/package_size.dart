// ignore_for_file: constant_identifier_names

enum PackageSize {
  S,
  M,
  L,
  XL,
}
