import 'package:flutter/widgets.dart';

abstract interface class IPositionedShape {
  Widget render(double x, double y);
}
