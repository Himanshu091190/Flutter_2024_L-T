enum ShapeType {
  circle,
  square,
}
